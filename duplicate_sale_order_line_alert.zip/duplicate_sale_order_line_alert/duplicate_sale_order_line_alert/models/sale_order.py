# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    @api.onchange('product_id')
    def onchange_check_duplicate_product_id(self):
        product_list = [rec.product_id.id for rec in self.order_id.order_line]
        if (product_list.count(self.product_id.id) > 2) and self.env.user.user_has_groups('product.group_product_variant'):
            return {
                'warning': {
                    'title': _('Warning!'),
                    'message': _('You have added the article … in duplicate'),
                }
            }





