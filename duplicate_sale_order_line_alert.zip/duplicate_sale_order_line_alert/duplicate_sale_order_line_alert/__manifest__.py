# -*- coding: utf-8 -*-
{
    'name': 'Check duplicate sale order line',
    'version': '15.0',
    'description': """Check duplicate sale order line""",
    'Author': 'Jawaher',
    'category': 'Tools',
    'website': 'https://www.d4e.cool',
    'depends': [
        'sale', 'product'
    ],
    'data': [],
    'installable': True,
    'application': False,
    'auto_install': False,

}
